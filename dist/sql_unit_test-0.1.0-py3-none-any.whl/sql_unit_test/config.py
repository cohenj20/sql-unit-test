from dotenv import load_dotenv
import os

TEST_FOLDER_PATH = '.'
LOG_LEVEL = 'WARN'

load_dotenv()

if os.getenv("TEST_FOLDER_PATH"):
    TEST_FOLDER_PATH = os.getenv("TEST_FOLDER_PATH")

if os.getenv("LOG_LEVEL"):
    LOG_LEVEL = os.getenv("LOG_LEVEL")
